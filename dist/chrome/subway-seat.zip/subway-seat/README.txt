Subway Seat — generated from palette.py by build.py. Edit the palette, not this file.
Unzip, open chrome://extensions, turn on Developer mode, Load unpacked → this folder.
